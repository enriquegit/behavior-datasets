Classify gestures by reading muscle activity. a recording of human hand muscle activity producing four different hand gestures.

Author: Kirill Yashuk

This dataset was originaly downloaded from: https://www.kaggle.com/kyr7plus/emg-4
