====== Complex Activities Dataset =======

This dataset consists of complex activities collected with a smartphone's accelerometer. An Android 2.2 application running on a LG Optimus Me cellphone was used to collect the accelerometer data from each of the axes (x,y,z). The sample rate was set at 50Hz but this is approximate since the Android SDK returns values just when a change is detected. The cellphone was placed in the user's belt and the data collection consisted of 5 long-term activities: commuting, working, at home, shopping and exercising. A training and a test set were collected in different days. The duration of the activities varies from about 5 minutes to a couple of hours. The total recorded data consists of approximately 41 hours. The data was collected by one user. Each file contains a whole activity.

The first integer in the filenames represents the activity id. The label mapping is:

1 commuting
2 work
3 home
4 shopping
5 exercising


CITATION: In all documents and papers that report experimental results based on this dataset, a reference to the following paper should be included:

Garcia-Ceja, E., & Brena, R. (2013). Long-term activity recognition from accelerometer data. Procedia Technology, 7, 248-256.

BibTex:

@article{garcia2013long,
  title={Long-term activity recognition from accelerometer data},
  author={Garcia-Ceja, Enrique and Brena, Ramon},
  journal={Procedia Technology},
  volume={7},
  pages={248--256},
  year={2013},
  publisher={Elsevier}
}
