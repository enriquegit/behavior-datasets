======= DEPRESJON Dataset ==========

Details about the dataset can be found in: https://datasets.simula.no/depresjon/

CITATION: In all documents and papers that report experimental results based on the Depresjon Dataset, a reference to this study should be included:

Enrique Garcia-Ceja, Michael Riegler, Petter Jakobsen, Jim Tørresen, Tine Nordgreen, Ketil J. Oedegaard, Ole Bernt Fasmer, Depresjon: A Motor Activity Database of Depression Episodes in Unipolar and Bipolar Patients, In MMSys'18 Proceedings of the 9th ACM on Multimedia Systems Conference, Amsterdam, The Netherlands, June 12 - 15, 2018.

BibTeX:

@inproceedings{GarciaCeja2018,
author = {Enrique Garcia-Ceja and Michael Riegler and Petter Jakobsen and Jim T\o rresen and Tine Nordgreen and Ketil J. Oedegaard and Ole Bernt Fasmer, },
title = {Depresjon: A Motor Activity Database of Depression Episodes in Unipolar and Bipolar Patients},
booktitle = {Proceedings of the 9th ACM on Multimedia Systems Conference},
series = {MMSys'18},
year = {2018},
location = {Amsterdam, The Netherlands},
url = {http://doi.acm.org/10.1145/3204949.3208125},
doi = {10.1145/3204949.3208125},
acmid = {3208125},
publisher = {ACM},
address = {New York, NY, USA}
}
